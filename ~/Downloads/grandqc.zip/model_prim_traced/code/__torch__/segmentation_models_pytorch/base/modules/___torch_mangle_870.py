class Attention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attention : __torch__.torch.nn.modules.linear.___torch_mangle_869.Identity
  def forward(self: __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_870.Attention) -> NoneType:
    attention = self.attention
    _0 = (attention).forward()
    return None
