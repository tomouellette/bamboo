class Activation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  activation : __torch__.torch.nn.modules.activation.___torch_mangle_915.Softmax
  def forward(self: __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_916.Activation,
    argument_1: Tensor) -> Tensor:
    activation = self.activation
    return (activation).forward(argument_1, )
