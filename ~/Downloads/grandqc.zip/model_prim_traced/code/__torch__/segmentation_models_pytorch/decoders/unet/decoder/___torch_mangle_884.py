class DecoderBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_875.Conv2dReLU
  attention1 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_877.Attention
  conv2 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_881.Conv2dReLU
  attention2 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_883.Attention
  def forward(self: __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_884.DecoderBlock,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    attention2 = self.attention2
    conv2 = self.conv2
    conv1 = self.conv1
    attention1 = self.attention1
    x = torch.upsample_nearest2d(argument_1, None, [2., 2.])
    input = torch.cat([x, argument_2], 1)
    _0 = (attention1).forward()
    _1 = (conv2).forward((conv1).forward(input, ), )
    _2 = (attention2).forward()
    return _1
