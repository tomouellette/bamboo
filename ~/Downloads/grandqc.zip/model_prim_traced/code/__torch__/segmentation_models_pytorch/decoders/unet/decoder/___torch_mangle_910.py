class DecoderBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_901.Conv2dReLU
  attention1 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_903.Attention
  conv2 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_907.Conv2dReLU
  attention2 : __torch__.segmentation_models_pytorch.base.modules.___torch_mangle_909.Attention
  def forward(self: __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_910.DecoderBlock,
    argument_1: Tensor) -> Tensor:
    attention2 = self.attention2
    conv2 = self.conv2
    conv1 = self.conv1
    input = torch.upsample_nearest2d(argument_1, None, [2., 2.])
    _0 = (conv2).forward((conv1).forward(input, ), )
    _1 = (attention2).forward()
    return _0
