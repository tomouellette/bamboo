class UnetDecoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  center : __torch__.torch.nn.modules.linear.___torch_mangle_845.Identity
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_911.ModuleList
  def forward(self: __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_912.UnetDecoder,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor,
    argument_4: Tensor,
    argument_5: Tensor) -> Tensor:
    blocks = self.blocks
    _4 = getattr(blocks, "4")
    blocks0 = self.blocks
    _3 = getattr(blocks0, "3")
    blocks1 = self.blocks
    _2 = getattr(blocks1, "2")
    blocks2 = self.blocks
    _1 = getattr(blocks2, "1")
    blocks3 = self.blocks
    _0 = getattr(blocks3, "0")
    center = self.center
    _5 = (center).forward()
    _6 = (_0).forward(argument_1, argument_2, )
    _7 = (_2).forward((_1).forward(_6, argument_3, ), argument_4, )
    _8 = (_4).forward((_3).forward(_7, argument_5, ), )
    return _8
