class Unet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.segmentation_models_pytorch.encoders.timm_efficientnet.___torch_mangle_844.EfficientNetEncoder
  decoder : __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_912.UnetDecoder
  segmentation_head : __torch__.segmentation_models_pytorch.base.heads.___torch_mangle_917.SegmentationHead
  def forward(self: __torch__.segmentation_models_pytorch.decoders.unet.model.___torch_mangle_918.Unet,
    x: Tensor) -> Tensor:
    segmentation_head = self.segmentation_head
    decoder = self.decoder
    encoder = self.encoder
    _0, _1, _2, _3, _4, = (encoder).forward(x, )
    _5 = (decoder).forward(_0, _1, _2, _3, _4, )
    return (segmentation_head).forward(_5, )
