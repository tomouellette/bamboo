class EfficientNetEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_stem : __torch__.torch.nn.modules.conv.___torch_mangle_605.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_606.BatchNorm2d
  act1 : __torch__.timm.models.layers.activations.___torch_mangle_607.Swish
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_837.Sequential
  conv_head : __torch__.torch.nn.modules.conv.___torch_mangle_838.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_839.BatchNorm2d
  act2 : __torch__.timm.models.layers.activations.___torch_mangle_840.Swish
  global_pool : __torch__.timm.models.layers.adaptive_avgmax_pool.___torch_mangle_843.SelectAdaptivePool2d
  def forward(self: __torch__.segmentation_models_pytorch.encoders.timm_efficientnet.___torch_mangle_844.EfficientNetEncoder,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    blocks = self.blocks
    _6 = getattr(blocks, "6")
    blocks0 = self.blocks
    _5 = getattr(blocks0, "5")
    blocks1 = self.blocks
    _4 = getattr(blocks1, "4")
    blocks2 = self.blocks
    _3 = getattr(blocks2, "3")
    blocks3 = self.blocks
    _2 = getattr(blocks3, "2")
    blocks4 = self.blocks
    _1 = getattr(blocks4, "1")
    blocks5 = self.blocks
    _0 = getattr(blocks5, "0")
    act1 = self.act1
    bn1 = self.bn1
    conv_stem = self.conv_stem
    _7 = (bn1).forward((conv_stem).forward(x, ), )
    _8 = (act1).forward(_7, )
    _9 = (_1).forward((_0).forward(_8, ), )
    _10 = (_2).forward(_9, )
    _11 = (_4).forward((_3).forward(_10, ), )
    _12 = ((_6).forward((_5).forward(_11, ), ), _11, _10, _9, _8)
    return _12
