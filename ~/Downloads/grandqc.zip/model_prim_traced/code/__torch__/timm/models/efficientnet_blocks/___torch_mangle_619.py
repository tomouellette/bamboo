class DepthwiseSeparableConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_dw : __torch__.torch.nn.modules.conv.___torch_mangle_608.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_609.BatchNorm2d
  act1 : __torch__.timm.models.layers.activations.___torch_mangle_610.Swish
  se : __torch__.timm.models.efficientnet_blocks.___torch_mangle_615.SqueezeExcite
  conv_pw : __torch__.torch.nn.modules.conv.___torch_mangle_616.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_617.BatchNorm2d
  act2 : __torch__.torch.nn.modules.linear.___torch_mangle_618.Identity
  def forward(self: __torch__.timm.models.efficientnet_blocks.___torch_mangle_619.DepthwiseSeparableConv,
    argument_1: Tensor) -> Tensor:
    act2 = self.act2
    bn2 = self.bn2
    conv_pw = self.conv_pw
    se = self.se
    act1 = self.act1
    bn1 = self.bn1
    conv_dw = self.conv_dw
    _0 = (bn1).forward((conv_dw).forward(argument_1, ), )
    _1 = (se).forward((act1).forward(_0, ), )
    _2 = (bn2).forward((conv_pw).forward(_1, ), )
    _3 = (act2).forward()
    return _2
