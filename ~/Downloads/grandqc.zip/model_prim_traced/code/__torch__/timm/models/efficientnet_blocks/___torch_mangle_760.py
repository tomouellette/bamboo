class SqueezeExcite(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_reduce : __torch__.torch.nn.modules.conv.___torch_mangle_756.Conv2d
  act1 : __torch__.timm.models.layers.activations.___torch_mangle_757.Swish
  conv_expand : __torch__.torch.nn.modules.conv.___torch_mangle_758.Conv2d
  gate : __torch__.torch.nn.modules.activation.___torch_mangle_759.Sigmoid
  def forward(self: __torch__.timm.models.efficientnet_blocks.___torch_mangle_760.SqueezeExcite,
    argument_1: Tensor) -> Tensor:
    gate = self.gate
    conv_expand = self.conv_expand
    act1 = self.act1
    conv_reduce = self.conv_reduce
    input = torch.mean(argument_1, [2, 3], True)
    _0 = (act1).forward((conv_reduce).forward(input, ), )
    _1 = (gate).forward((conv_expand).forward(_0, ), )
    return torch.mul(argument_1, _1)
