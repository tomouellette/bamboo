class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_pw : __torch__.torch.nn.modules.conv.___torch_mangle_765.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_766.BatchNorm2d
  act1 : __torch__.timm.models.layers.activations.___torch_mangle_767.Swish
  conv_dw : __torch__.torch.nn.modules.conv.___torch_mangle_768.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_769.BatchNorm2d
  act2 : __torch__.timm.models.layers.activations.___torch_mangle_770.Swish
  se : __torch__.timm.models.efficientnet_blocks.___torch_mangle_775.SqueezeExcite
  conv_pwl : __torch__.torch.nn.modules.conv.___torch_mangle_776.Conv2d
  bn3 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_777.BatchNorm2d
  def forward(self: __torch__.timm.models.efficientnet_blocks.___torch_mangle_778.InvertedResidual,
    argument_1: Tensor) -> Tensor:
    bn3 = self.bn3
    conv_pwl = self.conv_pwl
    se = self.se
    act2 = self.act2
    bn2 = self.bn2
    conv_dw = self.conv_dw
    act1 = self.act1
    bn1 = self.bn1
    conv_pw = self.conv_pw
    _0 = (bn1).forward((conv_pw).forward(argument_1, ), )
    _1 = (conv_dw).forward((act1).forward(_0, ), )
    _2 = (act2).forward((bn2).forward(_1, ), )
    _3 = (conv_pwl).forward((se).forward(_2, ), )
    return (bn3).forward(_3, )
