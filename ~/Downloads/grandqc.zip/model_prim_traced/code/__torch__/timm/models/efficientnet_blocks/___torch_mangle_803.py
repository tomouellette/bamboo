class SqueezeExcite(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_reduce : __torch__.torch.nn.modules.conv.___torch_mangle_799.Conv2d
  act1 : __torch__.timm.models.layers.activations.___torch_mangle_800.Swish
  conv_expand : __torch__.torch.nn.modules.conv.___torch_mangle_801.Conv2d
  gate : __torch__.torch.nn.modules.activation.___torch_mangle_802.Sigmoid
  def forward(self: __torch__.timm.models.efficientnet_blocks.___torch_mangle_803.SqueezeExcite,
    argument_1: Tensor) -> Tensor:
    gate = self.gate
    conv_expand = self.conv_expand
    act1 = self.act1
    conv_reduce = self.conv_reduce
    input = torch.mean(argument_1, [2, 3], True)
    _0 = (act1).forward((conv_reduce).forward(input, ), )
    _1 = (gate).forward((conv_expand).forward(_0, ), )
    return torch.mul(argument_1, _1)
