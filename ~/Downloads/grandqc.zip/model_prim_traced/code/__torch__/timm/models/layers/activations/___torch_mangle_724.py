class Swish(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.timm.models.layers.activations.___torch_mangle_724.Swish,
    argument_1: Tensor) -> Tensor:
    input = torch.mul_(argument_1, torch.sigmoid(argument_1))
    return input
