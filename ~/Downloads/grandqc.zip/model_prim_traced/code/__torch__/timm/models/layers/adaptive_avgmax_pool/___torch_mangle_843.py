class SelectAdaptivePool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  flatten : __torch__.torch.nn.modules.flatten.___torch_mangle_841.Flatten
  pool : __torch__.torch.nn.modules.pooling.___torch_mangle_842.AdaptiveAvgPool2d
