class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_858.DecoderBlock
  __annotations__["1"] = __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_871.DecoderBlock
  __annotations__["2"] = __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_884.DecoderBlock
  __annotations__["3"] = __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_897.DecoderBlock
  __annotations__["4"] = __torch__.segmentation_models_pytorch.decoders.unet.decoder.___torch_mangle_910.DecoderBlock
